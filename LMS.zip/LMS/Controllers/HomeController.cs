﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LMS.Models;

namespace LMS.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        private LMSEntities1 db = new LMSEntities1();
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult LibraryInfo()
        {
            return View();
        }
        public ActionResult LibrarianInfo()
        {
            var librarian = db.Librarians.ToList();
            return View(librarian);
        }

        public ActionResult Login()
        {
            return RedirectToAction("Login", "Login");
        }
        public ActionResult Logout()
        {
            // Clear the session
            Session.Clear();
            Session.Abandon();

            // Redirect to the Home page
            return RedirectToAction("Index", "Home");
        }
        public ActionResult Signup()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Signup(string role, string name, string username, string password)
        {
            try
            {
                //using (var db = new LMSEntities1())
                using (db)
                {
                    if (role == "Member")
                    {
                        var member = new Member
                        {
                            Name = name,
                            Username = username,
                            Password = password
                        };
                        db.Members.Add(member);
                    }
                    else if (role == "Librarian")
                    {
                        var librarian = new Librarian
                        {
                            Name = name,
                            Username = username,
                            Password = password
                        };
                        db.Librarians.Add(librarian);
                    }
                    else
                    {
                        ViewBag.Error = "Invalid role selected!";
                        return View();
                    }
                    db.SaveChanges();
                    ViewBag.Message = "Signup successful!";
                    return RedirectToAction("SignupSuccess");
                    //return RedirectToAction("Login", "Login");
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = "An error occurred: " + ex.Message;
                return View();
            }
        }
        public ActionResult SignupSuccess()
        {
            return View();
        }
    }
}
