﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LMS.Models;
using System.Data.Entity;

namespace LMS.Controllers
{
    public class MembersController : Controller
    {
        // GET: Members
        private LMSEntities1 db = new LMSEntities1();
        [HttpGet]
        public ActionResult MemberDashboard()
        {
            if (Session["UserRole"]?.ToString() != "Member")
                return RedirectToAction("Login", "Login");

            int memberId = (int)Session["UserID"]; // Assuming the member's ID is stored in the session
            var member = db.Members.Find(memberId);

            if (member != null)
            {
                ViewBag.MemberName = member.Name; // Replace 'Name' with the actual property for the member's name in your model
            }
            else
            {
                ViewBag.MemberName = "Member";
            }

            return View();
        }

        [HttpGet]
        public ActionResult ViewBooks()
        {
            var books = db.Books.Include(b => b.Author).Include(b => b.Genre).ToList();
            return View(books);
        }
        [HttpGet]
        public ActionResult ViewAuthors()
        {
            // Ensure the user is logged in as a Member
            if (Session["UserRole"]?.ToString() != "Member")
                return RedirectToAction("Login", "Login");

            // Fetch all authors from the database
            var authors = db.Authors.ToList();
            return View(authors);
        }

        [HttpGet]
        public ActionResult ViewGenres()
        {
            // Ensure the user is logged in as a Member
            if (Session["UserRole"]?.ToString() != "Member")
                return RedirectToAction("Login", "Login");

            // Fetch all genres from the database
            var genres = db.Genres.ToList();
            return View(genres);
        }

        [HttpGet]
        public ActionResult ViewPublishers()
        {
            // Ensure the user is logged in as a Member
            if (Session["UserRole"]?.ToString() != "Member")
                return RedirectToAction("Login", "Login");

            // Fetch all publishers from the database
            var publishers = db.Publishers.ToList();
            return View(publishers);
        }

        [HttpGet]
        public ActionResult ReserveBook()
        {
            // Ensure the user is logged in as a Member
            if (Session["UserRole"]?.ToString() != "Member")
                return RedirectToAction("Login", "Login");

            try
            {
                // Fetch books with available copies
                var availableBooks = db.Books
                    .Where(b => b.AvailableCopies > 0)
                    .Select(b => new
                    {
                        b.BookId,
                        b.Title
                    }).ToList();

                ViewBag.BookId = new SelectList(availableBooks, "BookId", "Title");
            }
            catch (Exception ex)
            {
                TempData["Error"] = "An error occurred while fetching books: " + ex.Message;
                return RedirectToAction("ReserveBook");
            }

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReserveBook(int BookId)
        {
            // Ensure the user is logged in as a Member
            if (Session["UserRole"]?.ToString() != "Member")
                return RedirectToAction("Login", "Login");

            try
            {
                int memberId = (int)Session["UserID"]; // Get the logged-in Member ID

                // Fetch the book
                var book = db.Books.Find(BookId);
                if (book == null)
                {
                    TempData["Error"] = "The selected book does not exist.";
                    return RedirectToAction("ReserveBook");
                }

                if (book.AvailableCopies <= 0)
                {
                    TempData["Error"] = "The selected book is not available.";
                    return RedirectToAction("ReserveBook");
                }

                // Create a new reservation
                var reservation = new Reservation
                {
                    MemberId = memberId,
                    BookId = BookId,
                    ReservationDate = DateTime.Now
                };

                // Save the reservation
                db.Reservations.Add(reservation);

                // Decrement available copies
                book.AvailableCopies--;

                db.SaveChanges();

                TempData["Message"] = "Book reserved successfully! Do you want to view your reserved books?";
                return RedirectToAction("ReserveBook"); // Redirect to the same page
            }
            catch (Exception ex)
            {
                TempData["Error"] = "An error occurred while reserving the book: " + ex.Message;
                return RedirectToAction("ReserveBook");
            }
        }

        [HttpGet]
        public ActionResult ViewReservedBooks()
        {
            // Ensure the user is logged in as a Member
            if (Session["UserRole"]?.ToString() != "Member")
                return RedirectToAction("Login", "Login");

            // Fetch reservations for the logged-in member
            int memberId = (int)Session["UserID"];
            var reservedBooks = db.Reservations
                .Where(r => r.MemberId == memberId)
                .Include(r => r.Book)
                .Include(r => r.Book.Author)
                .Include(r => r.Book.Genre)
                .ToList();

            return View(reservedBooks);
        }


        [HttpGet]
        public ActionResult BorrowBook()
        {
            // Ensure the user is logged in as a Member
            if (Session["UserRole"]?.ToString() != "Member")
                return RedirectToAction("Login", "Login");

            try
            {
                // Fetch books with available copies
                var availableBooks = db.Books
                    .Where(b => b.AvailableCopies > 0)
                    .Select(b => new
                    {
                        b.BookId,
                        b.Title
                    }).ToList();

                ViewBag.BookId = new SelectList(availableBooks, "BookId", "Title");
            }
            catch (Exception ex)
            {
                TempData["Error"] = "An error occurred while fetching available books: " + ex.Message;
                return RedirectToAction("BorrowBook");
            }

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BorrowBook(int BookId)
        {
            // Ensure the user is logged in as a Member
            if (Session["UserRole"]?.ToString() != "Member")
                return RedirectToAction("Login", "Login");

            try
            {
                int memberId = (int)Session["UserID"]; // Get the logged-in Member ID

                // Fetch the book
                var book = db.Books.Find(BookId);
                if (book == null)
                {
                    TempData["Error"] = "The selected book does not exist.";
                    return RedirectToAction("BorrowBook");
                }

                if (book.AvailableCopies <= 0)
                {
                    TempData["Error"] = "The selected book is not available.";
                    return RedirectToAction("BorrowBook");
                }

                // Create a new borrow record
                var borrow = new Borrow
                {
                    MemberId = memberId,
                    BookId = BookId,
                    BorrowDate = DateTime.Now,
                    DueDate = DateTime.Now.AddDays(14), // Set due date to 14 days later
                    ReturnDate = null
                };

                // Save the borrow record
                db.Borrows.Add(borrow);

                // Decrease the available copies of the book
                book.AvailableCopies--;

                db.SaveChanges();

                // Set confirmation message
                TempData["Message"] = "Book borrowed successfully! Do you want to view your borrowed books?";
                return RedirectToAction("BorrowBook"); // Redirect back to the borrow page
            }
            catch (Exception ex)
            {
                TempData["Error"] = "An error occurred while borrowing the book: " + ex.Message;
                return RedirectToAction("BorrowBook");
            }
        }


        [HttpGet]
        public ActionResult ViewBorrowedBooks()
        {
            // Ensure the user is logged in as a Member
            if (Session["UserRole"]?.ToString() != "Member")
                return RedirectToAction("Login", "Login");

            // Fetch borrow records for the logged-in member
            int memberId = (int)Session["UserID"];
            var borrowedBooks = db.Borrows
                .Where(b => b.MemberId == memberId && b.ReturnDate == null)
                .Include(b => b.Book)
                .ToList();

            return View(borrowedBooks);
        }

    }
}