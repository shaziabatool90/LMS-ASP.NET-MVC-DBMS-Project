﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using LMS.Models;

namespace LMS.Controllers
{
    public class LoginController : Controller
    {
        private LMSEntities1 db = new LMSEntities1();
        // GET: Login
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string username, string password, string role)
        {
            if (role == "Member")
            {
                var member = db.Members.FirstOrDefault(m => m.Username == username && m.Password == password);
                if (member != null)
                {
                    Session["UserRole"] = "Member";
                    Session["UserID"] = member.MemberId;
                    return RedirectToAction("MemberDashboard", "Members");
                }
            }
            else if (role == "Librarian")
            {
                var librarian = db.Librarians.FirstOrDefault(l => l.Username == username && l.Password == password);
                if (librarian != null)
                {
                    Session["UserRole"] = "Librarian";
                    Session["UserID"] = librarian.LibrarianId;
                    return RedirectToAction("LibrarianDashboard", "Librarian");
                }
            }

            ViewBag.Error = "Invalid credentials!";
            return View();
        }
    }
}