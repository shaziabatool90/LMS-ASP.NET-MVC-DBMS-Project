﻿using System.Linq;
using System.Web.Mvc;
using LMS.Models;

namespace LMS.Controllers
{
    public class LibrarianController : Controller
    {
        private LMSEntities1 db = new LMSEntities1();

        [HttpGet]
        public ActionResult LibrarianDashboard()
        {
            if (Session["UserRole"]?.ToString() != "Librarian")
                return RedirectToAction("Login", "Login");

            int librarianId = (int)Session["UserID"]; 
            var librarian = db.Librarians.Find(librarianId);

            if (librarian != null)
            {
                ViewBag.LibrarianName = librarian.Name; 
            }
            else
            {
                ViewBag.LibrarianName = "Librarian";
            }

            return View();
        }

    }
}
